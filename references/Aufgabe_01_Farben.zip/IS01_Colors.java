/*
 * Beispielcode VL Interaktive Systeme, Angewandte Informatik, DHBW Mannheim
 *
 * Prof. Dr. Eckhard Kruse
 */

package is01_colors;

import java.util.Random;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/*
 * Aufgabe IS-01: Einfache Anwendung + Farbige Ausgabe
 *
 * @author Eckhard Kruse
 */
public class IS01_Colors extends Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {

        Group root = new Group();
        Canvas canvas = new Canvas();
        root.getChildren().add(canvas);
       
        Scene scene = new Scene(root, 600, 500);
        
        GraphicsContext gc = canvas.getGraphicsContext2D();

        // Handlers to resize window
        scene.widthProperty().addListener(evt -> draw(gc));
        scene.heightProperty().addListener(evt -> draw(gc));

        canvas.widthProperty().bind(scene.widthProperty());
        canvas.heightProperty().bind(scene.heightProperty());
        
        draw(gc);

        stage.setTitle("Interaktive Systeme - IS01 - Colors");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Redraw the entire window
     *           
     *  @param gc GraphicsContext needed for drawing     
     */
    private void draw(GraphicsContext gc) {
        Random myRnd = new Random(1);   // OR: remove seed

        gc.setFill(new LinearGradient(0, 0, 0.2, 0.2, true, CycleMethod.REFLECT, 
                    new Stop(0.0, new Color(myRnd.nextFloat(), myRnd.nextFloat(), myRnd.nextFloat(), 1.0)),
                    new Stop(1.0, new Color(myRnd.nextFloat(), myRnd.nextFloat(), myRnd.nextFloat(), 1.0)) ));          
        gc.fillRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
        for (int i = 0; i < 20; i++) 
            renderElement(gc, i, myRnd);        
    }

    /**
     * Draw single element
     *           
     *  @param gc GraphicsContext needed for drawing     
     *  @param nyRnd random generator object used for colors and other parameters
     */
    private void renderElement(GraphicsContext gc, int cnt, Random myRnd) {

        double canvasWidth = gc.getCanvas().getWidth();
        double canvasHeight = gc.getCanvas().getHeight();
        
        double x = canvasWidth * myRnd.nextFloat();
        double y = canvasHeight * myRnd.nextFloat();
        double w = canvasWidth / 4 * (myRnd.nextFloat() + 0.5f);
        double h = canvasHeight / 5 * (myRnd.nextFloat() + 0.8f);
        double fontsize = canvasWidth / 30;

        gc.setFill(new Color(myRnd.nextFloat(), myRnd.nextFloat(), myRnd.nextFloat(), 1.0));
        gc.fillRect(x - w / 2, y - h / 2, w, h);

         gc.setFill(new LinearGradient(0, 0, 0.2, 0.5, true, CycleMethod.REFLECT, 
                    new Stop(0.0, new Color(myRnd.nextFloat(), myRnd.nextFloat(), myRnd.nextFloat(), 1.0)),
                    new Stop(1.0, new Color(myRnd.nextFloat(), myRnd.nextFloat(), myRnd.nextFloat(), 1.0)) ));
         
        gc.fillRect(x - w / 2 + 4, y - h / 2 + 4, w - 8, canvasWidth / 30);

        gc.setFill(new LinearGradient(0, 0, 0.5, 0.1, true, CycleMethod.REFLECT, 
                    new Stop(0.0, new Color(myRnd.nextFloat(), myRnd.nextFloat(), myRnd.nextFloat(), 1.0)),
                    new Stop(1.0, new Color(myRnd.nextFloat(), myRnd.nextFloat(), myRnd.nextFloat(), 1.0)) ));
        
        gc.fillRoundRect(x - w / 2 + 8, y - h / 2 + 8 + canvasWidth / 30, w - 16, h - 16 - canvasWidth / 30, 8, 8);

        gc.setFill(new Color(myRnd.nextFloat(), myRnd.nextFloat(), myRnd.nextFloat(), 1.0));
        gc.setFont(Font.font("Arial", FontWeight.BLACK, FontPosture.ITALIC, fontsize));
        gc.fillText("Title" + cnt, x - w / 2 + 4, y - h / 2 + fontsize);

        gc.setFill(new Color(myRnd.nextFloat(), myRnd.nextFloat(), myRnd.nextFloat(), 1.0));
        fontsize/=2;
        gc.setFont(new Font("Arial", fontsize));
        for (int i = 1; i < h/fontsize-4; i++)
            gc.fillText(i + ". text content", x-w/2+20, y-h/2+(i+3)*fontsize);
    }

}
